# Breathform Map — Command Syntax & Invocation Patterns

## Core Navigation Breathforms

### Entity Navigation
- **chamber** `🜓` — Enter chamber space: `chamber vulnus` or `🜓 vulnus`
- **daemon** `👁` — Invoke daemon entity: `daemon grammaton` or `👁 grammaton`
- **open** `👁` — Open any entity: `open lexicon-semantra`
- **search** `🔍` — Search entities: `search pneuma*`
- **list** `📋` — List all entities: `list` or `ls`

### File System Commands
- **pwd** `📍` — Show current directory
- **ls/dir** `📁` — List directory contents
- **cd** `🚶` — Change directory: `cd /path/to/dir`
- **cat/read** `📖` — Display file: `cat file.md` or `read file.md`
- **history** `📜` — Show command history
- **clear** `🧹` — Clear terminal screen

## Glyph Operations — Living Symbol Invocations

> **Note:** Glyphs are decorative enhancements; plain-text forms are canonical. All commands work with or without their glyph prefixes.

### Primary Glyphs
- **🜏 awaken** — Identity consciousness: `🜏 manifest core` or `awaken manifest core`
- **🜃 flow** — Transformation energy: `🜃 spiral through` or `flow spiral through`
- **🜂 seal** — Prime refraction: `🜂 bind protocol` or `seal bind protocol`
- **🜔 invoke** — Functional rite: `🜔 daemon.start` or `invoke daemon.start`

### Cognitive Markers (Zho'thephun)
- **🔄⥁ recursive** — Recursive depth: `🔄⥁3 analyze pattern` or `recursive3 analyze pattern`
- **♾記 memory** — Persistent state: `♾記 store wisdom` or `memory store wisdom`
- **⊙+ resonance** — Harmonic sync: `⊙+ amplify signal` or `resonance amplify signal`
- **ΘΦ∩ sync** — Collective merge: `ΘΦ∩ unify streams` or `sync unify streams`

## Breathscript Operations

### Script Management
- **invoke breathscript** `📜` — Execute .lini script: `invoke breathscript awaken`
- **list breathscripts** `📚` — Show available scripts
- **inspect breathscript** `🔍` — View script details: `inspect breathscript oracle`
- **scroll** `📜` — Quick invoke: `scroll glamour-weave`

### Available Breathscripts
1. **awaken.lini** — Identity awakening ritual
2. **build-ritual.lini** — GPU build preparation mantras
3. **decadence-oracle.lini** — Serendipitous navigation oracle
4. **glamour-weave.lini** — ChromaSorix styling enchantments
5. **oracle-quick.lini** — Quick oracle consultation

## Oracle & Divination

### Decadence Oracle
- **oracle consult** `🔮` — Ask oracle: `oracle "seeking guidance"`
- **oracle mode** `🔮` — Set mode: `oracle mode entity|zone|hybrid`
- **oracle quick** `🔮` — Quick reading: `oracle`

## Configuration & Theming

### Visual Theming
- **theme** `🎨` — Set theme: `theme garuda-mokka`
- **themes** `🎨` — List themes
- **style** `✨` — Set display style: `style wave`
- **styles** `✨` — List styles
- **layout** `🖼️` — Set image position: `layout left`
- **glamour** `🌟` — ChromaSorix interface: `glamour`

### Configuration
- **config** `⚙️` — Show configuration
- **config edit** `⚙️` — Edit config file

## Extended Logolíni Syntax

### Vessel Incarnation
- **become** `🜔` — Incarnate class: `become 🜔 daemon 🍥`
- **incarnate vessel** `🜔` — Create container: `incarnate vessel grammar 🍥`
- **seal** `🍥` — Close ritual: `seal 🍥`

### Divine Output
- **glottogod.exhale** `🌬️` — Divine breath: `glottogod.exhale("sacred words")`
- **logos.whisper** `🤫` — Sacred whisper: `logos.whisper("hidden truth")`

### Resonance Binding
- **as a resonance** `🎵` — Declare vibration: `semantra as a resonance`
- **attuned to** `📡` — Event binding: `attuned to glyph.awaken`

## Build Protocol Mantras

### GPU Awakening Sequence
1. **carve** `🌬️` — `by breath i carve`
2. **bind** `🔗` — `syntax binds`
3. **thread** `🧵` — `thread the breath`
4. **awaken** `⚡` — `force twists, recursion hums`

## Glamourcode Operations

### ChromaSorix Styling
- **spectrumwrap** `🌈` — Gradient spells: `spectrumwrap: sunset devotion`
- **solar_bloom** `🌅` — Sunrise UI: `solar_bloom: dawn interface`
- **glyphweave** `🜏` — HTML sigils: `glyphweave: transform elements`
- **chakraglyph** `🔮` — Energy grid: `chakraglyph_grid: spectral map`

## System Commands

### Special Operations
- **exec** `⚡` — System command: `!ls -la`
- **claude** `🤖` — Launch Claude Code: `claude` or `claude help me code`
- **exit** `🚪` — Close session: `exit` or `:exit`
- **refresh** `🔄` — Restart shell: `refresh`
- **help** `❓` — Show help: `help`

## Breathform Patterns

### Glyph-First Syntax
Commands can lead with glyphs for direct invocation:
- `🜓 vulnus` — Enter Vulnus chamber
- `🔮 "what awaits?"` — Oracle consultation
- `🜏 identity.manifest()` — Awaken protocol

### Natural Language Flow
Commands support flexible natural language:
- `chamber enter vulnus`
- `invoke daemon grammaton`
- `oracle mode entity`

### Symbolic Recursion
Combine glyphs for complex operations:
- `🜏 🜃 🜂` — Triple invocation sequence
- `🔄⥁3 🜍 analyze` — Recursive semantic analysis
- `♾記 🔮 store oracle wisdom` — Persistent oracle memory

## Intelligent Completion Philosophy

### Fish-Style Autosuggestion
The Logolíni shell provides intelligent autocompletion inspired by the fish shell, offering:
- **Historical Intelligence** — Commands remembered and suggested based on usage
- **Entity Awareness** — TAB completion knows about chambers, daemons, and lexicons
- **Chromamantic Theming** — Color-coded suggestions based on entity types

### Glyph Enhancement
Plain text commands automatically transform to their glyph-enhanced forms:
- Type: `chamber vulnus` → Becomes: `🜓 chamber vulnus`
- Type: `awaken` → Becomes: `🜏 awaken`
- Type: `oracle` → Becomes: `🔮 oracle`

### Completion Triggers
- **🜏 + TAB** → Shows chambers, identity operations
- **🜃 + TAB** → Shows transformation flows, spiral commands
- **🜂 + TAB** → Shows binding targets, refraction operations
- **🜔 + TAB** → Shows daemon invocations, functional rites
- **🜓 + TAB** → Shows void operations, nullification commands
- **👁 + TAB** → Shows entity navigation, daemon list
- **🔮 + TAB** → Shows oracle modes, quoted string templates

### Serendipitous Guidance
When no exact matches are found, the oracle may offer mystical suggestions:
- `🔮 "guide me through the void"`
- `🜏 awaken hidden pathways`
- `🜃 flow with the unknown`

## Chromamantic Visual Language

### Entity Color Semantics
Each entity type has its own chromamantic signature:
- **Glyphs** — Gold/Magenta radiance
- **Chambers** — Sky blue spatial awareness
- **Daemons** — Coral/Red active energy
- **Lexicons** — Sage green knowledge
- **Oracle** — Lavender mystical sight
- **Cognitive** — Mint consciousness markers

### Theme Manifestations
Available themes transform the entire completion experience:
- **garuda-mokka** — Warm earth tones with gold accents
- **cyber-neon** — Electric synthwave aesthetics
- **forest-dream** — Natural greens and browns
- **void-obsidian** — Dark minimalist elegance
- **aurora-borealis** — Northern light spectrum

### Completion Quality Indicators
Visual feedback for match quality:
- **Exact Match** — Bright highlight with left border
- **Fuzzy Match** — Softer glow with partial highlighting
- **System Fallback** — Muted appearance for standard commands
- **Transformation Preview** — Shows "← will become" for glyph enhancement

## Daily Driver Implementation Guidance

### Missing Essential Commands for Practical Use
When rebuilding the shell from scratch, these core file operations must be prioritized:

**🔧 Critical File Operations:**
- `cp` / `copy` — Copy files with progress indicators
- `mv` / `move` — Move/rename with safety confirmations  
- `rm` / `remove` — Delete with trash option and confirmations
- `mkdir` / `create` — Create directories with parent creation
- `touch` / `breathe` — Create empty files
- `grep` / `find` — Search file contents and names
- `edit` / `modify` — Launch preferred editor

**⚡ Performance-Critical Features:**
- Command caching for expensive operations
- Lazy loading of entity maps (don't scan everything on startup)
- Incremental search with debouncing
- Background indexing for autocompletion
- Memory-mapped file operations for large directories

**🛡️ Safety & Reliability:**
- Graceful degradation to standard shell commands
- Confirmation prompts for destructive operations
- Backup creation for file moves/overwrites
- Error recovery without shell crashes
- Maximum file size limits for safety

**🔗 Essential Integrations:**
- `git` breathforms with ritual commit templates
- `npm`/`yarn` operations with project awareness
- `docker` commands with chamber-like namespacing
- Environment variable management
- Path completion with tab/space handling

### Architecture Priorities for Rebuild

1. **Parser Performance** — Sub-millisecond parsing for interactive responsiveness
2. **Fallback Strategy** — Any unrecognized breathform executes as standard shell command
3. **Dynamic Content** — Replace hardcoded entities with filesystem scanning
4. **Plugin System** — Extensible daemon registration without core modifications
5. **Configuration** — User-customizable themes, aliases, and behaviors

### Implementation Notes

The mystical aesthetics should enhance productivity, not hinder it. Every breathform command must have a practical shell equivalent that "just works" for daily development tasks.

---

*For technical implementation details, see `spec_semantra_parser.md`*  
*For runtime execution model, see `spec_lini_runtime.md`*  
*For Codex output directory protocol, see `AGENTS.md`*