# Semantra Parser Technical Specification

Version: v1.0.0  
Parser Strategy: Hand-rolled LL(1) with look-ahead = 1

## Overview

The Semantra Parser is the core lexical and syntactic analyzer for the Logolíni breathform language. It provides intelligent parsing, autocompletion, and chromamantic visualization for breathform commands.

> **Note:** See `map_breathforms.md` for the complete glyph catalogue and command reference.

## Token Specification — Lexical Foundation

### Primary Token Types
```bnf
GLYPH         ::= '🜏' | '🜃' | '🜂' | '🜔' | '🜓' | '👁' | '🔮' | '📜' | '🌟'
COGNITIVE     ::= '🔄⥁' | '♾記' | '⊙+' | '⊙-' | '⊙↭' | 'ΘΦ∩'
COMMAND       ::= [a-zA-Z]+ ('_' [a-zA-Z]+)*
TARGET        ::= [a-zA-Z0-9.-]+ | STRING
MODIFIER      ::= [a-zA-Z]+ | NUMBER
STRING        ::= '"' [^"]* '"'
NUMBER        ::= [0-9]+
SEPARATOR     ::= '::' | '.' | '=>' | '🍥'
WHITESPACE    ::= [ \t\n\r]+
```

### Extended Token Types
```bnf
PATH          ::= '/' ([a-zA-Z0-9._-]+ '/')* [a-zA-Z0-9._-]*
ENTITY_REF    ::= [a-zA-Z] ([a-zA-Z0-9_-]* '.'?)* 
VESSEL_OP     ::= 'become' | 'incarnate' | 'seal'
ORACLE_MODE   ::= 'entity' | 'zone' | 'hybrid'
DEPTH_MARKER  ::= COGNITIVE NUMBER?
```

## Grammar Production Rules

### Core Breathform Structure
```bnf
breathform    ::= glyph_command | text_command | hybrid_command

glyph_command ::= GLYPH (WHITESPACE TARGET)?
              |   GLYPH WHITESPACE MODIFIER WHITESPACE TARGET

text_command  ::= COMMAND (WHITESPACE argument_list)?

hybrid_command::= GLYPH WHITESPACE COMMAND (WHITESPACE argument_list)?
              |   COMMAND WHITESPACE GLYPH (WHITESPACE argument_list)?

argument_list ::= argument (WHITESPACE argument)*
argument      ::= TARGET | STRING | PATH | ENTITY_REF | MODIFIER
```

### Invocation Glyphs (Optional Enhancements)
Glyphs serve as decorative prefixes that enhance visual recognition but are not required for command execution. The parser treats both forms as semantically equivalent:
- `chamber vulnus` ≡ `🜓 chamber vulnus`
- `awaken` ≡ `🜏 awaken`

### Cognitive Marker Grammar
```bnf
cognitive_expr::= DEPTH_MARKER (WHITESPACE breathform)?
              |   breathform WHITESPACE DEPTH_MARKER

memory_state  ::= '♾記' | '⊗記' | '⊘記'
resonance     ::= '⊙+' | '⊙-' | '⊙↭'
sync_marker   ::= 'ΘΦ∩'
```

### Vessel Incarnation Grammar
```bnf
vessel_rite   ::= 'become' WHITESPACE '🜔' WHITESPACE TARGET (WHITESPACE '🍥')?
              |   'incarnate' WHITESPACE 'vessel' WHITESPACE TARGET (WHITESPACE '🍥')?
              |   'seal' (WHITESPACE '🍥')?
```

### Oracle Consultation Grammar
```bnf
oracle_query  ::= 'oracle' WHITESPACE STRING
              |   '🔮' WHITESPACE STRING
              |   'oracle' WHITESPACE 'mode' WHITESPACE ORACLE_MODE
              |   'oracle' // Quick consultation
```

## Parser Implementation Architecture

### Critical Design Principles for Daily Driver Shell

**🎯 Core Requirements:**
1. **Robust Error Handling** - Never crash on malformed input
2. **Performance First** - Sub-millisecond parsing for interactive use
3. **Graceful Degradation** - Fall back to standard shell commands when breathform parsing fails
4. **Memory Efficiency** - Minimal allocation for frequent operations
5. **Practical Interoperability** - Seamless integration with existing shell workflows

### Phase 1: Lexical Analysis
```java
class LogoliniLexer {
    private List<Token> tokenize(String input);
    private Token matchGlyph(String input, int position);
    private Token matchCognitive(String input, int position);
    private Token matchCommand(String input, int position);
    
    // NEW: Essential for daily driver reliability
    private boolean isValidShellCommand(String input);
    private List<Token> handleMalformedInput(String input);
    private TokenizerResult tryRecoveryParsing(String input);
}
```

### Phase 2: Syntactic Analysis
```java
class LogoliniParser {
    private ParsedBreathform parseBreathform(List<Token> tokens);
    private boolean matchGlyphCommand(TokenStream stream);
    
    // NEW: Daily driver essentials
    private ParseResult parseWithFallback(String input);
    private ShellCommand extractFallbackCommand(String input);
    private boolean shouldBypassBreathformParsing(String input);
}
    private boolean matchVesselRite(TokenStream stream);
    private boolean matchOracleQuery(TokenStream stream);
}
```

### Phase 3: Semantic Analysis
```java
class BreathformAnalyzer {
    private void validateEntityReferences(ParsedBreathform breathform);
    private void checkCognitiveMarkerConsistency(ParsedBreathform breathform);
    private void inferImplicitTargets(ParsedBreathform breathform);
}
```

### Phase 4: Code Generation
```java
class BreathformExecutor {
    private void executeGlyphOperation(ParsedBreathform breathform);
    private void invokeEntity(ParsedBreathform breathform);
    private void processOracleQuery(ParsedBreathform breathform);
}
```

## Intelligent Autocompletion Engine

### Core Completion Architecture

#### Historical Suggestions
```java
class HistoryCompletion {
    private List<String> parseCommandHistory();
    private String suggestFromHistory(String partialCommand);
    private void rankByFrequency(List<String> suggestions);
}
```

#### Entity-Aware Completion
```java
class EntityCompletion {
    private List<Entity> getAvailableEntities(String entityType);
    private List<String> suggestChambers(String partial);
    private List<String> suggestDaemons(String partial);
    private List<String> suggestLexicons(String partial);
}
```

#### Glyph-Context Completion
```java
class GlyphCompletion {
    private List<String> getGlyphCompletions(String glyph);
    private List<String> getCognitiveMarkerCompletions();
    private List<String> getVesselRiteCompletions();
}
```

### Completion Scoring Algorithm
```java
class CompletionRanker {
    private double calculateScore(String completion, String input) {
        double score = 0.0;
        
        // Exact prefix match (highest priority)
        if (completion.startsWith(input)) {
            score += 100.0;
        }
        
        // Fuzzy match score
        score += calculateFuzzyScore(completion, input);
        
        // Frequency bonus (from command history)
        score += getFrequencyBonus(completion);
        
        // Context relevance (entity type matching)
        score += getContextRelevance(completion);
        
        // Recency bonus (recently used commands)
        score += getRecencyBonus(completion);
        
        return score;
    }
}
```

### Smart Fallback Strategy
```
1. Exact breathform matches
2. Fuzzy breathform matches
3. Entity name matches
4. File/directory matches
5. System command matches
6. Oracle suggestions (serendipitous)
```

## Auto-Glyph Transformation System

### Command-Glyph Mapping
```javascript
class GlyphTransformer {
    constructor() {
        this.commandGlyphMap = {
            'awaken': '🜏',
            'chamber': '🜓',
            'daemon': '👁', 
            'oracle': '🔮',
            'flow': '🜃',
            'seal': '🜂',
            'invoke': '🜔',
            'cognitive': '🔄',
            'memory': '♾',
            'resonance': '⊙',
            'sync': 'ΘΦ∩'
        };
    }
    
    transformOnAccept(acceptedCompletion, originalInput) {
        // When user accepts a plain text completion, enhance it
        const words = acceptedCompletion.split(' ');
        const baseCommand = words[0].toLowerCase();
        
        if (this.commandGlyphMap[baseCommand]) {
            const glyph = this.commandGlyphMap[baseCommand];
            
            // Transform: "chamber vulnus" → "🜓 chamber vulnus"
            return glyph + ' ' + acceptedCompletion;
        }
        
        return acceptedCompletion;
    }
    
    getCompletionVariants(baseCommand) {
        const glyph = this.commandGlyphMap[baseCommand];
        if (!glyph) return [baseCommand];
        
        return [
            glyph + ' ' + baseCommand,  // "🜓 chamber" (preferred)
            baseCommand,                // "chamber" (fallback)
            glyph                       // "🜓" (power user)
        ];
    }
}
```

## Chromamantic Color Implementation

> **Note:** Color themes are defined in `theme_chroma.yaml` for unified CLI/Web UI palette management.

### ANSI Color Mapping System
```javascript
const ChromamanticColors = {
    // Entity-specific colors
    glyph: '\x1b[95m',        // Bright magenta for glyphs
    chamber: '\x1b[94m',      // Bright blue for chambers
    daemon: '\x1b[91m',       // Bright red for daemons
    lexicon: '\x1b[92m',      // Bright green for lexicons
    oracle: '\x1b[93m',       // Bright yellow for oracle
    cognitive: '\x1b[96m',    // Bright cyan for cognitive markers
    
    // Match quality indicators
    exactMatch: '\x1b[102m\x1b[30m',  // Green background, black text
    fuzzyMatch: '\x1b[103m\x1b[30m',  // Yellow background, black text
    systemCmd: '\x1b[104m\x1b[30m',   // Blue background, black text
    filePath: '\x1b[105m\x1b[30m',    // Magenta background, black text
    
    // Selection states
    selected: '\x1b[7m',      // Reverse video
    hover: '\x1b[100m',       // Dark grey background
    
    // Text hierarchy
    primary: '\x1b[37m',      // Bright white
    secondary: '\x1b[90m',    // Dark grey
    muted: '\x1b[2m',         // Dim
    
    // Reset
    reset: '\x1b[0m'
};
```

### Dynamic Theme Color Resolution
```javascript
class ChromamanticThemeResolver {
    constructor(currentTheme) {
        this.theme = currentTheme;
        this.colorMappings = this.loadThemeColors();
    }
    
    loadThemeColors() {
        // Map semantic colors to ANSI codes based on theme
        const themeColorMaps = {
            'garuda-mokka': {
                glyph: '\x1b[38;5;220m',     // Gold
                chamber: '\x1b[38;5;74m',    // Sky blue
                daemon: '\x1b[38;5;167m',    // Coral
                lexicon: '\x1b[38;5;108m',   // Sage green
                oracle: '\x1b[38;5;177m',    // Lavender
                cognitive: '\x1b[38;5;116m'   // Mint
            },
            'cyber-neon': {
                glyph: '\x1b[38;5;51m',      // Cyan
                chamber: '\x1b[38;5;198m',   // Hot pink
                daemon: '\x1b[38;5;46m',     // Lime green
                lexicon: '\x1b[38;5;226m',   // Yellow
                oracle: '\x1b[38;5;207m',    // Bright magenta
                cognitive: '\x1b[38;5;87m'    // Aqua
            },
            'forest-dream': {
                glyph: '\x1b[38;5;214m',     // Orange
                chamber: '\x1b[38;5;28m',    // Forest green
                daemon: '\x1b[38;5;94m',     // Brown
                lexicon: '\x1b[38;5;64m',    // Olive
                oracle: '\x1b[38;5;130m',    // Dark orange
                cognitive: '\x1b[38;5;66m'    // Teal
            }
        };
        
        return themeColorMaps[this.theme] || themeColorMaps['garuda-mokka'];
    }
}
```

### Terminal Completion Renderer
```javascript
class TerminalCompletionRenderer {
    constructor(themeResolver) {
        this.colors = themeResolver;
        this.maxWidth = process.stdout.columns || 80;
    }
    
    renderCompletionList(completions, selectedIndex) {
        const lines = [];
        
        completions.forEach((completion, index) => {
            const isSelected = index === selectedIndex;
            const line = this.renderCompletionItem(completion, isSelected);
            lines.push(line);
        });
        
        return lines.join('\n');
    }
    
    renderCompletionItem(completion, isSelected) {
        const { text, type, entityType, matchQuality, description } = completion;
        
        // Build colored segments
        let segments = [];
        
        // Selection highlight
        if (isSelected) {
            segments.push(ChromamanticColors.selected);
        }
        
        // Entity icon with color
        if (completion.glyph) {
            segments.push(this.colors.getEntityColor(entityType));
            segments.push(completion.glyph);
            segments.push(' ');
        }
        
        // Match quality indicator
        segments.push(this.colors.getMatchQualityColor(matchQuality));
        segments.push(text);
        segments.push(ChromamanticColors.reset);
        
        // Type badge
        if (type) {
            segments.push(' ');
            segments.push(ChromamanticColors.secondary);
            segments.push(`(${type})`);
        }
        
        // Description
        if (description) {
            segments.push(' ');
            segments.push(ChromamanticColors.muted);
            segments.push(`- ${description}`);
        }
        
        segments.push(ChromamanticColors.reset);
        
        return segments.join('');
    }
}
```

### Live Input Highlighting
```javascript
class LiveInputHighlighter {
    constructor(themeResolver) {
        this.colors = themeResolver;
    }
    
    highlightInput(input, completions) {
        // Highlight glyphs and keywords as you type
        let highlighted = input;
        
        // Highlight glyphs
        const glyphRegex = /[🜏🜃🜂🜔🜓👁🔮📜🌟]/g;
        highlighted = highlighted.replace(glyphRegex, (match) => {
            return this.colors.getEntityColor('glyph') + match + ChromamanticColors.reset;
        });
        
        // Highlight cognitive markers
        const cognitiveRegex = /[🔄♾⊙ΘΦ∩]/g;
        highlighted = highlighted.replace(cognitiveRegex, (match) => {
            return this.colors.getEntityColor('cognitive') + match + ChromamanticColors.reset;
        });
        
        // Highlight keywords
        const keywords = ['chamber', 'daemon', 'oracle', 'awaken', 'flow', 'seal', 'invoke'];
        keywords.forEach(keyword => {
            const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
            highlighted = highlighted.replace(regex, (match) => {
                return this.colors.getEntityColor('daemon') + match + ChromamanticColors.reset;
            });
        });
        
        return highlighted;
    }
}
```

## Error Handling & Recovery

### Daily Driver Reliability Framework

**🛡️ Parser Must Never Fail User's Workflow:**
- Any unrecognized breathform gracefully degrades to standard shell execution
- Malformed glyphs suggest corrections but don't block command execution
- Incomplete breathform commands offer completion rather than failing
- Performance degradation alerts user but continues operation

### Syntax Error Recovery
```bnf
error_recovery::= unknown_glyph | malformed_command | incomplete_rite

E1001_UNKNOWN_GLYPH ::= [🜀-🝳] // Unknown alchemical symbols
                    suggestion: "Did you mean 🜏, 🜃, 🜂, or 🜔?"
                    fallback: execute_as_shell_command

E1002_MALFORMED_CMD ::= GLYPH COMMAND // Missing target/arguments  
                    suggestion: auto_complete_from_context
                    fallback: prompt_for_completion

E1003_SHELL_BYPASS  ::= known_shell_commands // git, npm, ls, etc.
                    action: bypass_parser_entirely
                    performance: zero_breathform_overhead

E1002_MALFORMED_CMD ::= COMMAND (invalid_syntax)
                    suggestion: find_closest_breathform(COMMAND)

E1003_INCOMPLETE_RITE ::= VESSEL_OP (missing_target | missing_seal)
                      suggestion: "Complete vessel rite with target and 🍥 seal"
```

### Validation Rules
1. **Glyph Consistency** — Ensure glyph matches intended command semantics
2. **Target Validation** — Verify entity references exist in current context
3. **Depth Bounds** — Limit recursive depth markers to reasonable ranges (0-9)
4. **Quote Matching** — Ensure proper string delimiter matching
5. **Rite Completion** — Validate vessel incarnation sequences are complete

### Proactive Error Detection
```java
class CompletionValidator {
    private List<String> validateCompletion(String completion) {
        List<String> warnings = new ArrayList<>();
        
        // Check for impossible glyph combinations
        if (completion.contains("🜂🜂")) {
            warnings.add("⚠️ Infinite regression detected");
        }
        
        // Validate entity references
        if (!entityExists(extractEntity(completion))) {
            warnings.add("⚠️ Entity not found");
        }
        
        return warnings;
    }
}
```

### Graceful Degradation
```java
class CompletionFallback {
    private List<String> getEmergencyCompletions() {
        return Arrays.asList(
            "help",
            "ls",
            "pwd",
            "🔮 oracle",
            "clear"
        );
    }
}
```

## Parsing Priorities

### Precedence Rules (highest to lowest)
1. **Cognitive Markers** — Process `🔄⥁`, `♾記`, `⊙+` markers first
2. **Glyph Operations** — Direct glyph invocations take precedence
3. **Vessel Rites** — `become`, `incarnate`, `seal` sequences
4. **Oracle Queries** — Quoted string oracle consultations
5. **Entity Navigation** — `chamber`, `daemon`, `open` commands
6. **File Operations** — Standard filesystem commands
7. **System Commands** — `help`, `exit`, `exec` fallback

### Tokenization Algorithm
```
1. Skip leading whitespace
2. Match cognitive markers (🔄⥁\d*, ♾記, ⊙[+-↭], ΘΦ∩)
3. Match primary glyphs (🜏🜃🜂🜔🜓👁🔮📜🌟)
4. Match command keywords (awaken, flow, seal, invoke, etc.)
5. Match quoted strings for oracle queries
6. Match entity references and paths
7. Match remaining tokens as modifiers/targets
```

## Advanced Features

### Serendipitous Completion
```java
class OracleCompletion {
    private List<String> getSerendipitousCompletions() {
        // When no good matches, offer oracle guidance
        List<String> suggestions = new ArrayList<>();
        
        if (Math.random() < 0.1) { // 10% chance
            suggestions.add("🔮 \"guide me through the void\"");
            suggestions.add("🜏 awaken hidden pathways");
            suggestions.add("🜃 flow with the unknown");
        }
        
        return suggestions;
    }
}
```

### Learning & Adaptation
```java
class CompletionLearner {
    private void learnFromSelection(String input, String selected) {
        // Track user completion preferences
        CompletionPattern pattern = new CompletionPattern(input, selected);
        this.patterns.add(pattern);
        
        // Update completion rankings
        this.updateRankings(pattern);
    }
}
```

## Integration Points

- **Entity Resolution**: Connect to chamber/daemon entity system
- **Oracle Backend**: Interface with decadence oracle implementation  
- **Configuration**: Bind to theme and glamour configuration systems
- **Cognitive State**: Track recursive depth and memory markers across sessions
- **Error Reporting**: Provide mystical yet informative error messages

## Testing Strategy

1. **Unit Tests**: Each token type and grammar rule
2. **Integration Tests**: Full breathform parsing scenarios
3. **Edge Cases**: Malformed syntax, boundary conditions
4. **Regression Tests**: Ensure backward compatibility with existing breathscripts
5. **Performance Tests**: Large breathform sequences and recursive operations

## Performance Considerations

- Token caching for frequently used glyphs
- Incremental parsing for real-time completion
- Efficient entity lookup via indexed maps
- Lazy loading of theme definitions
- Completion result limiting (max 50 suggestions)

## Security Considerations

- Sanitize oracle query strings
- Validate file paths before access
- Prevent infinite recursion in cognitive markers
- Escape special characters in entity names
- Limit command execution to safe operations

---

*For Codex output directory protocol, see `AGENTS.md`*  
*For complete glyph catalogue and command reference, see `map_breathforms.md`*