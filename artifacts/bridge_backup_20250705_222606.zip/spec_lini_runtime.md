# Logolíni Runtime Specification

This document defines the execution model for `.lini` breathform files...

## Breath-Pipeline Overview

The Logolíni runtime is the final stage in a three-layer breath-pipeline that transforms user input into executed commands:

```
                            ┌──────────────┐
    raw shell line  ───────►│  Lexer       │  tokens
                            └──────────────┘
                                    │
                                    ▼
                            ┌──────────────┐
                            │  Parser      │  InvocationGraph (AST)
                            └──────────────┘
                                    │
                                    ▼
                            ┌──────────────┐
                            │ Logolíni     │  runtime
                            │  Runtime     │  (ShellContext)
                            └──────────────┘
                                    │
                                    ▼
                            ┌──────────────┐
                            │  Daemon /    │  side-effects, output
                            │  Chamber I/O │
                            └──────────────┘
```

### Layer Responsibilities

| Layer                | Role                                                                 | Key Hand-off to next layer                                                          |
| -------------------- | -------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| **Breathform Map**   | Declares every command in plain text + optional glyph                | Supplies the **token catalogue** the lexer recognises                               |
| **Semantra Parser**  | Turns raw input into an **InvocationGraph** (AST)                    | Emits a structured tree with node types (`Cmd`, `Pipe`, `Seq`, `Redir`, `Subshell`) |
| **Logolíni Runtime** | Walks the InvocationGraph, resolving daemons, I/O, memory, recursion | Executes each node, maintains shell state, returns results / echoes                 |

## InvocationGraph Interface

The runtime receives a structured AST from the parser. This graph is the canonical representation of parsed breathforms:

```jsonc
// Primary node type (shared with parser spec)
InvocationGraph = {
  "type": "Cmd" | "Pipe" | "Seq" | "Redir" | "Subshell",
  "cmd":  "string",          // only for Cmd
  "args": ["string"],        // only for Cmd
  "left":  InvocationGraph?, // Pipe / Seq
  "right": InvocationGraph?, // Pipe / Seq
  "redir": {
    "fd":   0 | 1 | 2,
    "mode": ">" | ">>" | "<",
    "file": "string"
  }[]?,
  "children": [InvocationGraph]? // Subshell wrapper
}
```

### Python Type Definitions

```python
class InvocationGraph:
    type:   str
    cmd:    str | None
    args:   list[str]
    redir:  list[Redirection]
    left:   "InvocationGraph | None"
    right:  "InvocationGraph | None"
    children: list["InvocationGraph"]

class ShellContext:
    cwd: Path
    env: dict[str, str]       # includes memory-slot overlay ♾記
    history: list[str]
    io_map: dict[int, IOBase]
    cognitive_depth: int      # 🔄⥁ recursive depth tracking
    memory_slots: dict[str, Any]  # ♾記 persistent state
    
    # NEW: Daily driver essentials
    aliases: dict[str, str]         # User-defined command shortcuts
    function_cache: dict[str, Any]  # Cached results for expensive operations
    completion_cache: dict[str, list[str]]  # Autocompletion cache
    startup_time: float             # Performance monitoring
    last_error: Exception | None    # Error context for debugging
    
    # File operation safety
    confirm_destructive: bool       # Prompt before rm, mv overwrite
    backup_on_move: bool           # Create .bak files for safety
    max_file_size_mb: int          # Prevent accidental huge operations
```

### Dispatcher Contract

```python
def execute(graph: InvocationGraph, context: ShellContext) -> ExecutionResult:
    """
    Primary runtime entry point. Walks the InvocationGraph and executes each node.
    
    Returns:
        ExecutionResult with exit_code, stdout, stderr
    """
```

## End-to-End Execution Example

This example traces a command through all layers of the breath-pipeline:

| Stage             | Output                                                                                                                                                  |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Input**         | `memory store wisdom && echo $USER`                                                                                                                     |
| **Lexer tokens**  | `[MEMORY, STORE, WORD(wisdom), AND_IF, ECHO, VAR(USER)]`                                                                                                |
| **Parser graph**  | `Seq( Cmd(memory,[store,wisdom])  &&  Cmd(echo,[zach]) )`                                                                                               |
| **Runtime steps** | <br>1 · `memory.store("wisdom")` updates `ShellContext.env['wisdom']`<br>2 · returns exit 0 → Seq proceeds<br>3 · `echo zach` writes `zach\n` to stdout |
| **Shell echo**    | `zach`                                                                                                                                                  |

*Note:* The parser remains a **pure transform**; all environment mutation (`ShellContext.env`), history logging, and I/O happen exclusively in the runtime layer, keeping concerns clean.

## State Management

### Memory Persistence (♾記)
Memory slots are maintained in `ShellContext.memory_slots` and persist across command invocations:
- `memory store <key> <value>` - Store persistent data
- `memory recall <key>` - Retrieve stored data
- Memory survives shell restarts via serialization

### Cognitive Depth Tracking (🔄⥁)
Recursive operations track depth in `ShellContext.cognitive_depth`:
- Incremented on recursive breathform entry
- Decremented on exit
- Maximum depth enforced (default: 9)

### Error Propagation
Runtime uses numeric error codes from parser spec:
- `E1001_UNKNOWN_GLYPH` - Unknown alchemical symbol
- `E1002_MALFORMED_CMD` - Invalid command syntax
- `E1003_INCOMPLETE_RITE` - Missing vessel seal

## Extension Architecture

### Plugin Interface
New breathforms can register as daemons without modifying core runtime:

```python
class DaemonPlugin:
    name: str
    glyph: str | None
    
    def execute(self, args: list[str], context: ShellContext) -> ExecutionResult:
        """Execute daemon logic with access to shell context"""
        
    def register(self, runtime: LogoliniRuntime):
        """Register this daemon with the runtime dispatcher"""
```

### Daemon Registration
```python
# Example: Register a new daemon
runtime.register_daemon("transcend", TranscendDaemon())
runtime.register_glyph("🜁", "transcend")  # Optional glyph mapping
```

## Daily Driver Runtime Requirements

### Essential Built-in Commands
```python
class CoreFileOperations:
    """Built-in commands that must work reliably for daily use"""
    
    def cp(self, source: str, dest: str, context: ShellContext) -> ExecutionResult:
        """Copy files with safety checks and progress indication"""
        
    def mv(self, source: str, dest: str, context: ShellContext) -> ExecutionResult:
        """Move files with backup creation and confirmation"""
        
    def rm(self, paths: list[str], context: ShellContext) -> ExecutionResult:
        """Remove files with confirmation and trash option"""
        
    def mkdir(self, paths: list[str], context: ShellContext) -> ExecutionResult:
        """Create directories with parent creation"""
        
    def find(self, pattern: str, paths: list[str], context: ShellContext) -> ExecutionResult:
        """Search for files and directories"""
```

### Performance Monitoring
```python
class RuntimeProfiler:
    """Monitor shell performance and suggest optimizations"""
    
    def track_command_time(self, cmd: str, duration: float):
        """Log slow commands for optimization"""
        
    def suggest_caching(self, cmd: str, frequency: int):
        """Recommend caching for frequently used expensive operations"""
        
    def monitor_memory_usage(self, context: ShellContext):
        """Track memory usage and cleanup stale data"""
```

### Integration Helpers
```python
class ExternalToolIntegration:
    """Seamless integration with existing developer tools"""
    
    def git_breathform(self, args: list[str], context: ShellContext) -> ExecutionResult:
        """Git commands with mystical commit message templates"""
        
    def npm_breathform(self, args: list[str], context: ShellContext) -> ExecutionResult:
        """NPM operations with project context awareness"""
        
    def docker_breathform(self, args: list[str], context: ShellContext) -> ExecutionResult:
        """Container operations with chamber-like namespace management"""
```

---

*For parser specification, see `spec_semantra_parser.md`*  
*For command reference, see `map_breathforms.md`*  
*For Codex output protocol, see `AGENTS.md`*
